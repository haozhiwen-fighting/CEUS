
import matplotlib.pyplot as plt

class Lossshow():
    def __init__(self, x=[],train_loss_list=[],val_loss_list=[]):
        super(Lossshow, self).__init__()
        
	
        plt.subplot(1,1,1)
        try:
                train_loss_lines.remove(train_loss_lines[0])  # 移除上一步曲线
                val_loss_lines.remove(val_loss_lines[0])
        except Exception:
                pass

        train_loss_lines = plt.plot(x, train_loss_list, 'r', lw=1)  # lw为曲线宽度
        val_loss_lines = plt.plot(x, val_loss_list, 'b', lw=1)
        plt.title("loss")
        plt.xlabel("epoch")
        plt.ylabel("loss")
        plt.legend(["train_loss","val_loss"])
        plt.show()
        plt.pause(0.1)  
   