from cProfile import label
from lib2to3.pytree import type_repr
import os
import time
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import json
from PIL import Image
import io
import torchvision
import cv2
import re
from scipy import ndimage as ndimg
from torchvision import transforms
import matplotlib.pyplot as plt
class CEUSNET(Dataset):
    #视频读取
    def __init__(self,data_dir, preprocess=None, split = 'train',frames=7, classes=2, ):  
        video_root= os.path.join(data_dir, split)   #视频路径
        src = []
        for clslabel in os.listdir(video_root):
            video_path = os.path.join(video_root+'/', clslabel)
            for videoname in os.listdir(video_path):
                frame_path = os.path.join(video_path+'/', videoname+'/keyframes')
                videoframes=[]
                for framename in os.listdir(frame_path):
                    videoframes.append(framename)
                src.append([videoname,videoframes[-1],clslabel])  #视频名和对应的标签名
        
        self.src = src
        self.data_dir = data_dir
        self.classes = classes
        self.split=split
        self.frames = frames
        self.preprocess = preprocess
        self.alpha=[1,4,7,11]     ###1,4,7,11 #1 4 11 15
        self.scale=1
        self.mask_cnt=4


    def __len__(self):
        return len(self.src)     #返回视频文件的长度

    def transform(self, img):
        tran =  transforms.Compose([
                                    transforms.Resize((224,224)),
                                    transforms.ToTensor(),
                                    transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5)),
                                    ])
        return tran(img)
    def transform1(self, img):
        tran =  transforms.Compose([
                                    transforms.Resize((224,224)),
                                    transforms.ToTensor(),
                                    transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5)),
                                    ])
        return tran(img)
    def make_text_region(self, img, polygons):
        # h, w = img.shape[0]//self.scale, img.shape[1]//self.scale
        mask_zeros = np.zeros((600,600), np.uint8)
        tr_mask = np.zeros((600,600), np.float)
        for polygon in polygons:
            instance_mask = mask_zeros.copy()
            cv2.fillPoly(instance_mask, [polygon.points.astype(np.int32)], color=(1,))
            dmp = ndimg.distance_transform_edt(instance_mask[::self.scale, ::self.scale])  # distance transform
            for i, k in enumerate(self.alpha):
                tr_mask[:, :, i] = np.maximum(tr_mask[:, :, i], self.sigmoid_alpha(dmp, k))
        return tr_mask
    def sigmoid_alpha(self, x, k):
        betak = (1 + np.exp(-k)) / (1 - np.exp(-k))
        dm = max(np.max(x), 0.0001)
        res = (2 / (1 + np.exp(-x*k/dm)) - 1)*betak
        a=np.maximum(0, res)
        return np.maximum(0, res)
    def general_tr_mask(self, img):
        img=np.asarray(img)/255
        mask_zeros = np.zeros((600,800), np.uint8)
        mask_ones = np.ones((600,800), np.uint8)
        tr_mask = np.zeros((600,800,self.mask_cnt), np.float)
        train_mask = np.ones((600,800), np.uint8)
        dmp = ndimg.distance_transform_edt(img[:,:,0])
        for i, k in enumerate(self.alpha):
                tr_mask[:, :, i] = np.maximum(tr_mask[:, :, i], self.sigmoid_alpha(dmp, k))
        train_mask=mask_ones[::self.scale,::self.scale]
        return tr_mask,train_mask
    def __getitem__(self, idx):

        if torch.is_tensor(idx):
            idx = idx.tolist()     #数组/矩阵转换为列表
        filename = self.src[idx][0]     #获取文件名
        clslabel=self.src[idx][2]   #获取哪一类文件
        vf=[]     #获取每一帧
        vframes=[]
        vframes1=[]
        i=0
        a=0
        video_root = os.path.join(self.data_dir, self.split )
        video_path=os.path.join(video_root+'/',clslabel)
        for franame in os.listdir(os.path.join(video_path+'/',filename+'/keyframes' )):                            
            if i<self.frames:
                vf.append(franame)
            i=i+1
        #####排序
        tmp=[]
        newtmp=[]
        # print(len(vf))
        for i in range(len(vf)):
            tmp.append(re.findall('\d+',vf[i]))
        for i in range(len(tmp)):
            newtmp.append(int(tmp[i][0]))
        nums=newtmp
        for i in range(len(nums)):    
            for j in range(len(nums)-i-1):  
                if nums[j] > nums[j+1]:
                    nums[j], nums[j+1] = nums[j+1], nums[j]
                    vf[j], vf[j+1] = vf[j+1], vf[j]
        j=0
        for j in range(len(vf)):
            if j>0 and j<5:
                vframes.append(vf[j])
            j+=1
        j=0
        #转化为向量
        for id,imgframe in enumerate(vframes):
            path=os.path.join(video_root+'/',clslabel)
            video_path=os.path.join(path+'/',filename+'/keyframes/')
            path2=os.path.join(video_path,imgframe)
            image2 = Image.open(path2)  # PIL的JpegImageFile格式(size=(W，H))
            img2_tensor = self.transform(image2)
            vframes[id]=img2_tensor
        vframes=torch.stack(vframes,0).float()
        # label = self.src[idx][1]
        label=video_path.split('keyframes')[0]+'mask.png'
        # imagelabel = Image.open(f'{video_path}/{label}')
        imagelabel = Image.open(label)
        tr_mask,train_mask=self.general_tr_mask(imagelabel)
        tr_mask = np.clip(tr_mask, 0, 1)
        train_mask = np.clip(train_mask, 0, 1)
        tran =  transforms.Compose([
                                    transforms.Resize((224,224)),
                                    transforms.ToTensor(),
                                    #transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5)),
                                    ])
        tran1 =  transforms.Compose([
                                    transforms.Resize((224,224)),
                                    transforms.ToTensor(),
                                    #transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5)),
                                    ])
        label=tran(imagelabel)
        train_mask=Image.fromarray(train_mask)
        train_mask=tran1(train_mask)
        tr_ten=[]
        for i in range(4):
            mask=Image.fromarray(tr_mask[:,:,i])
            mask=tran1(mask)
            tr_ten.append(mask)
        tr_mask=torch.stack(tr_ten,3).float().squeeze(dim=0)

        # tr_mask=tran1(tr_mask)
        sample=(vframes,vframes1,label,clslabel,filename)
        return vframes,label,train_mask,tr_mask,filename
        # return vframes,label,tr_mask
