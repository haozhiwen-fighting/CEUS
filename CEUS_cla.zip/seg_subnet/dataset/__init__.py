from .dataload import *
from .total_text import TotalText
from .synth_text import SynthText
from .ctw1500_text import Ctw1500Text
from .Icdar15_Text import Icdar15Text
from .Icdar17_Text import Mlt2017Text
from .TD500_Text import TD500Text
from .deploy import DeployDataset
