import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from einops import rearrange, repeat
def passthrough(x, **kwargs):
    return x

def ELUCons(elu, nchan):
    if elu:
        return nn.ELU(inplace=True)
    else:
        return nn.PReLU(nchan)

# normalization between sub-volumes is necessary
# for good performance
class ContBatchNorm3d(nn.modules.batchnorm._BatchNorm): 
    def _check_input_dim(self, input):
        super(ContBatchNorm3d, self).__init__()
        if input.dim() != 5:
            raise ValueError('expected 5D input (got {}D input)'
                             .format(input.dim()))
        # super(ContBatchNorm3d, self)._check_input_dim(input)

    def forward(self, input):
        # self._check_input_dim(input)
        return F.batch_norm(
            input, self.running_mean, self.running_var, self.weight, self.bias,
            True, self.momentum, self.eps)


class LUConv(nn.Module):
    def __init__(self, nchan, elu):
        super(LUConv, self).__init__()
        self.relu1 = ELUCons(elu, nchan)
        self.conv1 = nn.Conv3d(nchan, nchan, kernel_size=5, padding=2)
        self.bn1 = ContBatchNorm3d(nchan)

    def forward(self, x):
        out = self.relu1(self.bn1(self.conv1(x)))
        return out


def _make_nConv(nchan, depth, elu):
    layers = []
    for _ in range(depth):
        layers.append(LUConv(nchan, elu))
    return nn.Sequential(*layers)


class InputTransition(nn.Module):
    def __init__(self, outChans, elu):
        super(InputTransition, self).__init__()
        self.conv1 = nn.Conv3d(1, 8, kernel_size=5, padding=2)
        self.bn1 = ContBatchNorm3d(8)
        self.relu1 = ELUCons(elu, 8)

    def forward(self, x0,x):
        # do we want a PRELU here as well?
        # x=self.conv1(x0)
        out = self.bn1(x)
        # out = self.bn1(self.conv1(x))
        # split input in to 16 channels
        # x16 = torch.cat((x, x, x, x, x, x, x, x,
        #                  x, x, x, x, x, x, x, x), 1)
        # x0 = torch.cat((x, x, x, x, x, x, x, x), 1)
        # x0 = torch.cat((x0, x0, x0, x0, x0, x0, x0, x0), 1)
        # out = self.relu1(torch.add(out, x16))
        out = self.relu1(torch.add(out, x0))
        return out


class DownTransition(nn.Module):
    def __init__(self, inChans, nConvs, elu, dropout=False):
        super(DownTransition, self).__init__()
        outChans = 2*inChans
        self.down_conv = nn.Conv3d(inChans, outChans, kernel_size=(1,2,2), stride=(1,2,2))
        self.down_conv1 = nn.Conv3d(outChans, outChans, kernel_size=(3,1,1), stride=(1,1,1),padding=(1,0,0))
        self.bn1 = ContBatchNorm3d(outChans)
        self.do1 = passthrough
        self.relu1 = ELUCons(elu, outChans)
        self.relu2 = ELUCons(elu, outChans)
        if dropout:
            self.do1 = nn.Dropout3d()
        self.ops = _make_nConv(outChans, nConvs, elu)

    def forward(self, x):
        down = self.relu1(self.bn1(self.down_conv1(self.down_conv(x))))
        out = self.do1(down)
        out = self.ops(out)
        out = self.relu2(torch.add(out, down))
        return out


class UpTransition(nn.Module):
    def __init__(self, inChans, outChans, nConvs, elu, dropout=False):
        super(UpTransition, self).__init__()
        self.up_conv = nn.ConvTranspose3d(inChans, outChans // 2, kernel_size=(1,2,2), stride=(1,2,2))
        self.up_conv1 = nn.ConvTranspose3d(outChans // 2, outChans // 2, kernel_size=(3,1,1), stride=(1,1,1),padding=(1,0,0))
        self.bn1 = ContBatchNorm3d(outChans // 2)
        self.do1 = passthrough
        self.do2 = nn.Dropout3d()
        self.relu1 = ELUCons(elu, outChans // 2)
        self.relu2 = ELUCons(elu, outChans)
        if dropout:
            self.do1 = nn.Dropout3d()
        self.ops = _make_nConv(outChans, nConvs, elu)

    def forward(self, x, skipx):
        out = self.do1(x)
        skipxdo = self.do2(skipx)
        out = self.relu1(self.bn1(self.up_conv1(self.up_conv(out))))
        xcat = torch.cat((out, skipxdo), 1)
        out = self.ops(xcat)
        out = self.relu2(torch.add(out, xcat))
        return out


class OutputTransition(nn.Module):
    def __init__(self, inChans, elu, nll):
        super(OutputTransition, self).__init__()
        self.conv1 = nn.Conv3d(inChans, 2, kernel_size=5, padding=2)
        self.bn1 = ContBatchNorm3d(2)
        self.conv2 = nn.Conv3d(2, 2, kernel_size=1)
        self.relu1 = ELUCons(elu, 2)
        self.seg=nn.Conv3d(2,2,kernel_size=(4,1,1),stride=1,padding=0)
        

    def forward(self, x):
        # convolve 32 down to 2 channels
        out = self.relu1(self.bn1(self.conv1(x)))
        out = self.conv2(out)
        out=self.seg(out).squeeze(dim=2)
        # make channels the last axis
        # return out.permute(1,0,2,3)
        return out
def swish(x, inplace: bool = False):
    """Swish - Described in: https://arxiv.org/abs/1710.05941
    """
    return x.mul_(x.sigmoid()) if inplace else x.mul(x.sigmoid())
class Swish(nn.Module):
    def __init__(self, inplace: bool = False):
        super(Swish, self).__init__()
        self.inplace = inplace

    def forward(self, x):
        return swish(x, self.inplace)
# class InnerBlock(nn.Module):
#     def __init__(self, dim, kernel_size, project_dim=2):
#         super(InnerBlock, self).__init__()

#         self.project_dim = project_dim
#         self.dim = dim
#         self.kernel_size = kernel_size

#         self.key_embed = nn.Sequential(
#             nn.Conv2d(dim, dim, self.kernel_size, stride=1, padding=self.kernel_size//2, groups=4, bias=False),
#             nn.BatchNorm2d(dim),
#             nn.ReLU(inplace=True)
#         )

#         share_planes = 8
#         factor = 2
#         self.embed = nn.Sequential(
#             nn.Conv2d(2*dim, dim//factor, 1, bias=False),
#             nn.BatchNorm2d(dim//factor),
#             nn.ReLU(inplace=True),
#             nn.Conv2d(dim//factor, dim, kernel_size=1),
#             nn.GroupNorm(num_groups=dim // share_planes, num_channels=dim)
#         )

#         self.conv1x1 = nn.Sequential(
#             nn.Conv3d(dim, dim, kernel_size=1, stride=1, padding=0, dilation=1, bias=False),
#             nn.BatchNorm3d(dim)
#         )

#         self.bn = nn.BatchNorm3d(dim)
#         self.act = Swish(inplace=True)

#         reduction_factor = 4
#         self.radix = 2
#         attn_chs = max(dim * self.radix // reduction_factor, 32)
#         self.se = nn.Sequential(
#             nn.Conv3d(dim, attn_chs, 1),
#             nn.BatchNorm3d(attn_chs),
#             nn.ReLU(inplace=True),
#             nn.Conv3d(attn_chs, self.radix*dim, 1)
#         )
#         self.ttt=nn.Conv3d(dim,dim,(4,1,1),1)
#     def forward(self, x):
#         kl=self.ttt(x).squeeze(dim=self.project_dim)
#         # k2=torch.max(x, self.project_dim)
#         # k = torch.mean(x, self.project_dim) + torch.max(x, self.project_dim)[0]
#         k = kl + torch.max(x, self.project_dim)[0]
#         k = self.key_embed(k)
#         # q = torch.mean(x, self.project_dim) + torch.max(x, self.project_dim)[0]
#         q = kl + torch.max(x, self.project_dim)[0]
#         qk = torch.cat([q, k], dim=1)

#         w = self.embed(qk)
#         w = w.unsqueeze(self.project_dim)
#         fill_shape = w.shape[-1]
#         repeat_shape = [1,1,1,1,1]
#         # repeat_shape[self.project_dim] = fill_shape
#         w = w.repeat(repeat_shape)
        
#         v = self.conv1x1(x)
#         v = v * w
#         v = self.bn(v)
#         v = self.act(v)

#         B, C, H, W, D = v.shape
#         v = v.view(B, C, 1, H, W, D)
#         x = x.view(B, C, 1, H, W, D)
#         x = torch.cat([x, v], dim=2)

#         x_gap = x.sum(dim=2)
#         x_gap = x_gap.mean((2, 3, 4), keepdim=True)
#         x_attn = self.se(x_gap)
#         x_attn = x_attn.view(B, C, self.radix)
#         x_attn = F.softmax(x_attn, dim=2)
#         out = (x * x_attn.reshape((B, C, self.radix, 1, 1, 1))).sum(dim=2)
        
#         return out.contiguous()
class InnerBlock(nn.Module):
    def __init__(self, dim, kernel_size, project_dim=2):
        super(InnerBlock, self).__init__()
        self.project_dim = project_dim
        self.dim = dim
        self.kernel_size = kernel_size
        self.key_embed = nn.Sequential(
            nn.Conv2d(dim, dim, self.kernel_size, stride=1, padding=self.kernel_size//2, groups=4, bias=False),
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True)
        )

        share_planes = 8
        factor = 2
        self.embed = nn.Sequential(
            nn.Conv2d(2*dim, dim//factor, 1, bias=False),
            nn.BatchNorm2d(dim//factor),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim//factor, dim, kernel_size=1),
            nn.GroupNorm(num_groups=dim // share_planes, num_channels=dim)
        )

        self.conv1x1 = nn.Sequential(
            nn.Conv3d(dim, dim, kernel_size=1, stride=1, padding=0, dilation=1, bias=False),
            nn.BatchNorm3d(dim)
        )

        self.bn = nn.BatchNorm3d(dim)
        self.act = Swish(inplace=True)

        reduction_factor = 4
        self.radix = 2
        attn_chs = max(dim * self.radix // reduction_factor, 32)
        self.se = nn.Sequential(
            nn.Conv3d(dim, attn_chs, 1),
            nn.BatchNorm3d(attn_chs),
            nn.ReLU(inplace=True),
            nn.Conv3d(attn_chs, self.radix*dim, 1)
        )
        self.ttt=nn.Conv3d(dim,dim,(4,1,1),1)
        # self.ttt=nn.Conv3d(dim,dim,(7,1,1),1)
        # self.ttt = nn.Sequential(
        #     nn.Conv3d(dim, dim, (7,1,1),1),
        #     nn.BatchNorm3d(dim),
        #     nn.ReLU(inplace=True),
        # )
        # self.channel = nn.Linear(196, 1)
        # # self.channel_fin = nn.Linear(512, 128)
        # self.channel_fin = nn.Linear(896, 128)
        # self.channel_fin = nn.Linear(1024, 256)
    def forward(self, x):
        kl=self.ttt(x).squeeze(dim=self.project_dim)
        # kl=torch.mean(x, self.project_dim)
        # k = torch.mean(x, self.project_dim) + torch.max(x, self.project_dim)[0]
        k = kl + torch.max(x, self.project_dim)[0]
        k = self.key_embed(k)
        # q = torch.mean(x, self.project_dim) + torch.max(x, self.project_dim)[0]
        q = kl + torch.max(x, self.project_dim)[0]
        qk = torch.cat([q, k], dim=1)

        w = self.embed(qk)
        w = w.unsqueeze(self.project_dim)
        fill_shape = w.shape[-1]
        repeat_shape = [1,1,1,1,1]
        # repeat_shape[self.project_dim] = fill_shape
        w = w.repeat(repeat_shape)
        
        v = self.conv1x1(x)
        v = v * w
        v = self.bn(v)
        v = self.act(v)

        B, C,T, H, W = v.shape
        v = v.view(B, C, 1,T, H, W)
        x_channel1=rearrange(x,' b c t h w-> b (c t) h w')
        x_channel2=rearrange(x,' b c t h w-> b (c t) (h w)')
        x = x.view(B, C, 1, T,H, W)
        x = torch.cat([x, v], dim=2)

        
        # x_channel1=x_channel1.mean((2,3), keepdim=True)
        # x_channel2=self.channel(x_channel2).view(B,T*C,1,1)
        # x_channel2=torch.sigmoid(x_channel2)
        # x_channel=x_channel1+x_channel2
        # x_channel=self.channel_fin(x_channel.view(B,T*C)).reshape(B, C, 1, 1, 1)
        # x_channel=torch.sigmoid(x_channel)

        x_gap = x.sum(dim=2)
        x_gap = x_gap.mean((2, 3, 4), keepdim=True)

        x_attn = self.se(x_gap)
        x_attn = x_attn.view(B, C, self.radix)
        x_attn = F.softmax(x_attn, dim=2)
        out = (x * x_attn.reshape((B, C, self.radix, 1, 1, 1))).sum(dim=2)
        # out=out*x_channel

        return out.contiguous()


class VNet(nn.Module):
    # the number of convolutions in each layer corresponds
    # to what is in the actual prototxt, not the intent
    def __init__(self, elu=True, nll=False,pretrain=True):
        super(VNet, self).__init__()
        self.in_tr = InputTransition(8, elu)
        self.down_tr32 = DownTransition(8, 1, elu)
        self.down_tr64 = DownTransition(16, 2, elu)
        self.down_tr128 = DownTransition(32, 3, elu, dropout=True)
        self.down_tr256 = DownTransition(64, 2, elu, dropout=True)
        self.up_tr256 = UpTransition(128,128, 2, elu, dropout=True)
        self.up_tr128 = UpTransition(128, 64, 2, elu, dropout=True)
        self.up_tr64 = UpTransition(64, 32, 1, elu)
        self.up_tr32 = UpTransition(32, 16, 1, elu)
        self.out_tr = OutputTransition(16, elu, nll)
        self.conv=nn.Conv3d(3,1,1)
        self.tem = nn.Sequential(
            nn.Conv3d(128, 128, 1, padding=0),
            nn.BatchNorm3d(128),
            nn.ReLU(inplace=True))
        self.temporal=InnerBlock(dim=128, kernel_size=3, project_dim=2)
    def forward(self, x0,x):
        # x0=x0.permute(0,2,1,3,4)
        # x0=x0[:,:,7:11,:,:]
        # x0=self.conv(x0)
        out16 = self.in_tr(x0,x)    #16 8
        out32 = self.down_tr32(out16)
        out64 = self.down_tr64(out32)
        out128 = self.down_tr128(out64)
        out256 = self.down_tr256(out128)   #16,256
        out256=self.tem(out256)
        out256=self.temporal(out256)
        out = self.up_tr256(out256, out128)
        out = self.up_tr128(out, out64)
        out = self.up_tr64(out, out32)
        out = self.up_tr32(out, out16)
        out = self.out_tr(out)
        return out