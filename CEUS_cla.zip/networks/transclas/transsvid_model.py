from typing import Tuple, Union
import torch
import torch.nn as nn
import torch
from torchvision import models
from torch import dropout, nn, einsum
import torch.nn.functional as F
from argparse import Namespace
import timm
from timm.data import resolve_data_config
from timm.data.transforms_factory import create_transform
from typing import Sequence, Union
from networks.transclas.trans_cla import TransformerBlock
from networks.transclas.transattention import Attention,SABlock
from networks.transclas.embed import PatchEmbeddingBlock
from einops import rearrange, repeat
from einops.layers.torch import Rearrange
from torchvision import transforms
from monai.networks.blocks.dynunet_block import UnetOutBlock
from monai.networks.blocks import UnetrBasicBlock, UnetrPrUpBlock, UnetrUpBlock
from networks.c3d import C3D
from networks.cla import DenseNet2d
# import sklearn.svm as svm

class Conv3dReLU(nn.Sequential):
    def __init__(
            self,
            in_channels,
            out_channels,
            kernel_size,
            padding=0,
            stride=1,
            use_batchnorm=True,
    ):
        conv = nn.Conv3d(
            in_channels,
            out_channels,
            kernel_size,
            stride=stride,
            padding=padding,
            bias=not (use_batchnorm),
        )
        relu = nn.ReLU(inplace=True)

        bn = nn.BatchNorm3d(out_channels)

        super(Conv3dReLU, self).__init__(conv, bn, relu)
class VTN(nn.Module):
    def __init__(
        self,
        frames,
        in_channels: int,
        img_size: Union[Sequence[int], int],
        patch_size: Union[Sequence[int], int],
        hidden_size: int = 768,
        mlp_dim: int = 3072,
        num_layers: int = 3,
        num_heads: int = 4,       #12》4
        pos_embed: str = "conv",
        classification: bool = False,
        num_classes: int = 1,
        dropout_rate: float = 0.5,
        spatial_dims: int = 3,
    ) -> None:   
        super().__init__()
        self.frames = frames
        # self.patch_embedding = PatchEmbeddingBlock(
        #     in_channels=in_channels,
        #     img_size=img_size,
        #     patch_size=patch_size,
        #     hidden_size=hidden_size,
        #     num_heads=num_heads,
        #     pos_embed=pos_embed,
        #     dropout_rate=dropout_rate,
        #     spatial_dims=spatial_dims,
        # )
        #######
        self.dens=DenseNet2d(num_init_features=2)
        # self.dens=C3D(num_classes=2, pretrained=False)
        #####
        self.layers = nn.ModuleList(
          [TransformerBlock(dim=768,hidden_size=768, mlp_dim=1536,heads=4,dropout_rate=0.1,dim_head=32) for i in range(num_layers)]
          )   
        self.norm = nn.LayerNorm(hidden_size)
        # self.cls_token = nn.Parameter(torch.zeros(1, 1, hidden_size))
        # self.pos_embedding = nn.Parameter(torch.randn(1, 4, hidden_size))
        self.dropout=nn.Dropout(0.1)
    def forward(self, img):
       #########
        b,c , h,w,T=img.shape
        img=rearrange(img,'b c h w t-> (b t ) c h w')
        img=self.dens(img)
        x=rearrange(img,'(b t) d-> b t d',t=T)
        # x=torch.cat((self.cls_token,x),dim=1)
        # embeddings = x + self.pos_embedding[:, :4]
        # x = self.dropout(embeddings)
        # x = self.patch_embedding(img)
        hidden_states_out = []
        for blk in self.layers:
            x = blk(x)
            hidden_states_out.append(x)
        x = self.norm(x)      
        return x,img

class UNETRcla(nn.Module):
    
    def __init__(
        self,
        frames:int,
        in_channels: int,
        out_channels: int,
        img_size: Tuple[int, int],
        feature_size: int = 16,
        hidden_size: int = 768,
        mlp_dim: int = 3072,
        num_heads: int = 1,
        pos_embed: str = "conv",
        norm_name: Union[Tuple, str] = "instance",
        conv_block: bool = False,
        res_block: bool = True,
        dropout_rate: float = 0.5,
    ) -> None:
        """
        Args:
            in_channels: dimension of input channels.
            out_channels: dimension of output channels.
            img_size: dimension of input image.
            feature_size: dimension of network feature size.
            hidden_size: dimension of hidden layer.
            mlp_dim: dimension of feedforward layer.
            num_heads: number of attention heads.
            pos_embed: position embedding layer type.
            norm_name: feature normalization type and arguments.
            conv_block: bool argument to determine if convolutional block is used.
            res_block: bool argument to determine if residual block is used.
            dropout_rate: faction of the input units to drop.
        """

        super().__init__()

        if not (0 <= dropout_rate <= 1):
            raise AssertionError("dropout_rate should be between 0 and 1.")

        if hidden_size % num_heads != 0:
            raise AssertionError("hidden size should be divisible by num_heads.")

        if pos_embed not in ["conv", "perceptron"]:
            raise KeyError(f"Position embedding layer of type {pos_embed} is not supported.")
        self.hidden_size = hidden_size
        self.classification = True
        self.vit = VTN(frames=frames, 
                        in_channels=in_channels,
                          img_size=img_size, 
                          patch_size=(16,16,4),    #7>4
                          hidden_size=hidden_size,
                          mlp_dim=mlp_dim,
                          num_layers=0,    #3需要更改的参数                         
                          num_heads= 4,       #12》4
                          pos_embed="conv",
                          classification=True,
                          num_classes=1,
                          dropout_rate=0.1,
                          spatial_dims=3                                        
            )
        #########
        self.conv4a = nn.Conv3d(3, 3, kernel_size=(3, 1, 1), padding=(1, 0, 0))
        # self.conv4b = nn.Conv3d(32, 32, kernel_size=(3, 3, 3), padding=(1, 1, 1))
        self.pool4 = nn.MaxPool3d(kernel_size=(2, 1, 1), stride=(2, 1, 1), padding=(0, 0, 0))

        self.conv5a = nn.Conv3d(3, 3, kernel_size=(3, 1, 1), padding=(1, 0, 0))
        # self.conv5b = nn.Conv3d(64, 64, kernel_size=(3, 3, 3), padding=(1, 1, 1))
        self.pool5 = nn.MaxPool3d(kernel_size=(2, 1, 1), stride=(2, 1, 1), padding=(0, 0, 0))
        # self.fc=nn.Linear(1024,768)
        #########
        self.dropout = nn.Dropout(p=0.1)
        # self.cov=nn.Conv3d(3, 3, kernel_size=(3, 1, 1), padding=(1, 0, 0))
        # self.pool = nn.MaxPool3d(kernel_size=(7, 1, 1), stride=(7, 1, 1), padding=(0, 0, 0))
        self.layer=nn.LayerNorm(768)
    def forward(self, x_in):
        x_in = x_in.permute(0, 1, 3, 4, 2)
        x,x1= self.vit(x_in)
        x=self.dropout(x) 
        x = x.view(x.size(0),3, 4,16, 16).contiguous()  
        #########
        # x=self.dropout(self.pool4(self.conv4b(self.conv4a(x))))
        # x=self.dropout(self.pool5(self.conv5b(self.conv5a(x))))
        x=self.dropout(self.pool4(self.conv4a(x)))
        x=self.dropout(self.pool5(self.conv4a(x)))
        ############### 
        # x=self.cov(x)
        # x=self.pool(x)
        x = x.view(x.size(0), -1)
        # x=self.fc(x)
        return x