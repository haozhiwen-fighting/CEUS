
import numpy as np
import numpy as np
import os
from skimage import io
from PIL import Image
import cv2
import math
import SimpleITK as sitk
import vtk
import glob
from stl import mesh
from shapely.geometry import Polygon
import nrrd
import pydicom

# a=np.array([[1,2,3,4],[1,2,3,4]])
# b=np.where(a == 1, a, 0)
def get_volume(dcm_path,bmp_data_dir):
    # pixel_infos = get_pixel_info(dcm_data_dir)
    pixels_No = 0
    bmp_files = os.listdir(bmp_data_dir)
    for bmp in bmp_files:
        bmp_file = os.path.join(bmp_data_dir,bmp)
        img = Image.open(bmp_file).convert('RGB')
        img_array = np.array(img)
        # img_array.dtype为布尔类型，需要转换为Int类型，其累加和恰好为体素总和
        img_array_int = img_array.astype(int)
        pixels_No = pixels_No+img_array_int.sum()
    # pixels_No = get_pixels_No(bmp_data_dir)
    pixel_infos = []
    # dcm_files = os.listdir(dcm_data_dir)
 
    # dcm_file_1 = os.path.join(dcm_data_dir,dcm_files[0])
    dcm_tag_1 = pydicom.read_file(dcm_path)
    # 获取像素间距.
    spacex, spacey = dcm_tag_1.PixelSpacing
    spacez=dcm_tag_1.SliceThickness
    # spacex, spacey = 0.300000011920929, 0.300000011920929
    # spacez=0.299999237060547
    volume=spacex*spacey*spacez*pixels_No/1000
    return volume
v=get_volume(dcm_path='D:/data/dataset/airlabel/dicom/2yexiao/Xia0012.dcm',bmp_data_dir='D:/HHJ/3D segmenation/Swin-Unet-main/Result_VA/0001/VIS/VIS_2D_6/')

aaa=1
