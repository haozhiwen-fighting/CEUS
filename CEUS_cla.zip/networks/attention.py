import torch
import torch.nn as nn
from torch import  einsum
import numpy as np
import copy
import logging
import math
from torch.nn import CrossEntropyLoss, Dropout, Softmax, Linear, Conv2d, LayerNorm
from torch.nn.modules.utils import _pair
from scipy import ndimage
from monai.utils import optional_import
from math import sqrt
from einops import rearrange, repeat
from einops.layers.torch import Rearrange
import torch.autograd as autograd
import torch.nn.functional as F
einops, _ = optional_import("einops")


class SABlock(nn.Module):
    """
    A self-attention block, based on: "Dosovitskiy et al.,
    An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale <https://arxiv.org/abs/2010.11929>"
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        dropout_rate: float = 0.0,
    ) -> None:
        """
        Args:
            hidden_size: dimension of hidden layer.
            num_heads: number of attention heads.
            dropout_rate: faction of the input units to drop.

        """

        super(SABlock, self).__init__()

        if not (0 <= dropout_rate <= 1):
            raise ValueError("dropout_rate should be between 0 and 1.")

        if hidden_size % num_heads != 0:
            raise ValueError("hidden size should be divisible by num_heads.")

        self.num_heads = num_heads
        self.out_proj = nn.Linear(hidden_size, hidden_size)
        self.qkv = nn.Linear(hidden_size, hidden_size * 3, bias=False)
        self.drop_output = nn.Dropout(dropout_rate)
        self.drop_weights = nn.Dropout(dropout_rate)
        self.head_dim = hidden_size // num_heads
        self.scale = self.head_dim ** -0.5

    def forward(self, x):
        q, k, v = einops.rearrange(self.qkv(x), "b h (qkv l d) -> qkv b l h d", qkv=3, l=self.num_heads)
        att_mat = (torch.einsum("blxd,blyd->blxy", q, k) * self.scale).softmax(dim=-1)
        att_mat = self.drop_weights(att_mat)
        x = torch.einsum("bhxy,bhyd->bhxd", att_mat, v)
        x = einops.rearrange(x, "b h l d -> b l (h d)")
        x = self.out_proj(x)
        x = self.drop_output(x)
        return x
class SABlock_channel(nn.Module):
    """
    A self-attention block, based on: "Dosovitskiy et al.,
    An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale <https://arxiv.org/abs/2010.11929>"
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        dropout_rate: float = 0.0,
    ) -> None:
        """
        Args:
            hidden_size: dimension of hidden layer.
            num_heads: number of attention heads.
            dropout_rate: faction of the input units to drop.

        """

        super(SABlock_channel, self).__init__()

        if not (0 <= dropout_rate <= 1):
            raise ValueError("dropout_rate should be between 0 and 1.")

        if hidden_size % num_heads != 0:
            raise ValueError("hidden size should be divisible by num_heads.")
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.out_proj = nn.Linear(hidden_size, self.num_heads*self.head_dim)
        self.qkv = nn.Linear(hidden_size, hidden_size* 3, bias=False)
        self.drop_output = nn.Dropout(dropout_rate)
        self.drop_weights = nn.Dropout(dropout_rate)
        # self.head_dim = hidden_size // num_heads
        self.scale = self.head_dim ** -0.5
        self.bn = nn.LayerNorm(self.head_dim)
    def forward(self, x):
        q, k, v = einops.rearrange(self.qkv(x), "b h (qkv l d) -> qkv b l h d", qkv=3, l=self.num_heads)
        q=q.chunk(self.num_heads,2)
        k=k.chunk(self.num_heads,2)
        v=v.chunk(self.num_heads,2)
        M_A=[]
        for i in range(self.num_heads):
            query_i = q[i].contiguous()
            query_i = self.bn(query_i)
            key_i = k[i].contiguous()
            value_i = v[i].contiguous()

            att_mat = (torch.einsum("blxd,blyd->blxy", query_i, key_i) * self.scale).softmax(dim=-1)
            att_mat = self.drop_weights(att_mat)
            x = torch.einsum("bhxy,bhyd->bhxd", att_mat, value_i)
            x = einops.rearrange(x, "b h l d -> b l (h d)")
            M_A.append(x)
        x = torch.cat(M_A, dim=1)
        x = self.out_proj(x)
        x = self.drop_output(x)
        return x
class Attention(nn.Module):
    def __init__(self, config, vis):
        super(Attention, self).__init__()
        self.vis = vis
        self.num_attention_heads = config.transformer["num_heads"]
        self.attention_head_size = int(config.hidden_size / self.num_attention_heads)
        self.all_head_size = self.num_attention_heads * self.attention_head_size

        self.query = Linear(config.hidden_size, self.all_head_size)
        self.key = Linear(config.hidden_size, self.all_head_size)
        self.value = Linear(config.hidden_size, self.all_head_size)

        self.out = Linear(config.hidden_size, config.hidden_size)
        self.attn_dropout = Dropout(config.transformer["attention_dropout_rate"])
        self.proj_dropout = Dropout(config.transformer["attention_dropout_rate"])

        self.softmax = Softmax(dim=-1)

    def transpose_for_scores(self, x):
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(self, hidden_states):
        mixed_query_layer = self.query(hidden_states)
        mixed_key_layer = self.key(hidden_states)
        mixed_value_layer = self.value(hidden_states)

        query_layer = self.transpose_for_scores(mixed_query_layer)
        key_layer = self.transpose_for_scores(mixed_key_layer)
        value_layer = self.transpose_for_scores(mixed_value_layer)

        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        attention_scores = attention_scores / math.sqrt(self.attention_head_size)
        attention_probs = self.softmax(attention_scores)
        weights = attention_probs if self.vis else None
        attention_probs = self.attn_dropout(attention_probs)

        context_layer = torch.matmul(attention_probs, value_layer)
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(*new_context_layer_shape)
        attention_output = self.out(context_layer)
        attention_output = self.proj_dropout(attention_output)
        return attention_output, weights

def default(val, default_val):
    return val if val is not None else default_val

def init_(tensor):
    dim = tensor.shape[-1]
    std = 1 / math.sqrt(dim)
    tensor.uniform_(-std, std)
    return tensor
class LinformerSelfAttention(nn.Module):
    def __init__(self, dim, seq_len, k = 256, heads = 8, dim_head = None, one_kv_head = False, share_kv = False, dropout = 0.):
        super().__init__()
        assert (dim % heads) == 0, 'dimension must be divisible by the number of heads'

        self.seq_len = seq_len
        self.k = k

        self.heads = heads

        dim_head = default(dim_head, dim // heads)
        self.dim_head = dim_head

        self.to_q = nn.Linear(dim, dim_head * heads, bias = False)

        kv_dim = dim_head if one_kv_head else (dim_head * heads)
        self.to_k = nn.Linear(dim, kv_dim, bias = False)
        self.proj_k = nn.Parameter(init_(torch.zeros(seq_len, k)))

        self.share_kv = share_kv
        if not share_kv:
            self.to_v = nn.Linear(dim, kv_dim, bias = False)
            self.proj_v = nn.Parameter(init_(torch.zeros(seq_len, k)))

        self.dropout = nn.Dropout(dropout)
        self.to_out = nn.Linear(dim_head * heads, dim)

    def forward(self, x, context = None, **kwargs):
        b, n, d, d_h, h, k = *x.shape, self.dim_head, self.heads, self.k

        kv_len = n if context is None else context.shape[1]
        assert kv_len == self.seq_len, f'the sequence length of the key / values must be {self.seq_len} - {kv_len} given'

        queries = self.to_q(x)

        proj_seq_len = lambda args: torch.einsum('bnd,nk->bkd', *args)

        kv_input = x if context is None else context

        keys = self.to_k(kv_input)
        values = self.to_v(kv_input) if not self.share_kv else keys

        kv_projs = (self.proj_k, self.proj_v if not self.share_kv else self.proj_k)

        # project keys and values along the sequence length dimension to k

        keys, values = map(proj_seq_len, zip((keys, values), kv_projs))

        # merge head into batch for queries and key / values

        queries = queries.reshape(b, n, h, -1).transpose(1, 2)

        merge_key_values = lambda t: t.reshape(b, k, -1, d_h).transpose(1, 2).expand(-1, h, -1, -1)
        keys, values = map(merge_key_values, (keys, values))

        # attention

        dots = torch.einsum('bhnd,bhkd->bhnk', queries, keys) * (d_h ** -0.5)
        attn = dots.softmax(dim=-1)
        attn = self.dropout(attn)
        out = torch.einsum('bhnk,bhkd->bhnd', attn, values)

        # split heads
        out = out.transpose(1, 2).reshape(b, n, -1)
        return self.to_out(out)
class Relevance_Measuring(autograd.Function):
    def forward(ctx, query, key, radius=1, dilation=1):
        ctx.radius = radius
        ctx.dilation = dilation

        b, t, c, h, w = query.shape
        local_size = 2 * radius + 1
        size = (b, t, local_size * local_size * t, h, w)
        weight = torch.zeros(size, dtype=query.dtype, layout=query.layout, device=query.device)
        weight.fill_(-np.inf)
        return weight
class Spatial_Temporal_Aggregation(autograd.Function):
    def forward(ctx, weight, proj, radius=1, dilation=1):
        ctx.radius = radius
        ctx.dilation = dilation
        out = torch.zeros_like(proj)
        return out

relevance_measuring = Relevance_Measuring.apply
spatial_temporal_aggregation = Spatial_Temporal_Aggregation.apply
class chnnel_attention(nn.Module):
    def __init__(self, channels_in=32, n_head=4, d_k=8, d_v=8):
        super(chnnel_attention, self).__init__()
        self.n_head = n_head
        self.d_k = d_k
        self.query_conv = nn.Conv3d(channels_in, n_head * d_k, 1, bias=False)
        self.key_conv = nn.Conv3d(channels_in, n_head * d_k, 1, bias=False)
        self.value_conv = nn.Conv3d(channels_in, n_head * d_v, 1, bias=False)
        self.output_Linear = nn.Conv3d(n_head * d_v, channels_in, 1, bias=False)
        self.bn = nn.LayerNorm([8, 16, 28])

    def forward(self, x):
        dilation, radius = [1, 3, 5, 7], [3, 3, 3, 3]
        x_ = x.permute(0, 2, 1, 3, 4).contiguous()

        query = self.query_conv(x_).permute(0, 2, 1, 3, 4)
        query_chunk = query.chunk(self.n_head, 2)
        key = self.key_conv(x_).permute(0, 2, 1, 3, 4)
        key_chunk = key.chunk(self.n_head, 2)
        value = self.value_conv(x_).permute(0, 2, 1, 3, 4)
        value_chunk = value.chunk(self.n_head, 2)

        M_T, M_A = [], []

        for i in range(self.n_head):
            query_i = query_chunk[i].contiguous()
            query_i = self.bn(query_i)
            key_i = key_chunk[i].contiguous()
            value_i = value_chunk[i].contiguous()
            M_A_i = relevance_measuring(query_i, key_i, radius[i], dilation[i]) / sqrt(8)
            M_A.append(F.softmax(M_A_i, dim=2))
            M_T.append(spatial_temporal_aggregation(M_A_i, value_i, radius[i], dilation[i]))

        M_S, _ = torch.max(torch.cat(M_A, dim=2), dim=2)
        M_T = torch.cat(M_T, dim=2).permute(0, 2, 1, 3, 4)
        out_cat = self.output_Linear(M_T) * M_S.unsqueeze(2).permute(0, 2, 1, 3, 4)

        return out_cat.permute(0, 2, 1, 3, 4)

class CrossAttention(nn.Module):
    def __init__(self, dim, heads = 8, dim_head = 64, dropout = 0.):
        super().__init__()
        inner_dim = dim_head *  heads
        project_out = not (heads == 1 and dim_head == dim)

        self.heads = heads
        self.scale = dim_head ** -0.5

        self.to_k = nn.Linear(dim, inner_dim , bias=False)
        self.to_v = nn.Linear(dim, inner_dim , bias = False)
        self.to_q = nn.Linear(dim, inner_dim, bias = False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x_q,x_qkv):
        b, n, _, h = *x_qkv.shape, self.heads

        k = self.to_k(x_qkv)
        k = rearrange(k, 'b n (h d) -> b h n d', h = h)

        v = self.to_v(x_qkv)
        v = rearrange(v, 'b n (h d) -> b h n d', h = h)

        q = self.to_q(x_q)
        q = rearrange(q, 'b n (h d) -> b h n d', h = h)



        dots = einsum('b h i d, b h j d -> b h i j', q, k) * self.scale

        attn = dots.softmax(dim=-1)

        out = einsum('b h i j, b h j d -> b h i d', attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        out =  self.to_out(out)
        return out
# class MultiScaleTransformerEncoder(nn.Module):

#     def __init__(self, small_dim = 768, small_dim_head = 32,
#                  large_dim = 192, large_dim_head = 64, 
#                  cross_attn_depth = 1, cross_attn_heads = 3, dropout = 0.):
#         super().__init__()
#         self.cross_attn_layers = nn.ModuleList([])
#         for _ in range(cross_attn_depth):
#             self.cross_attn_layers.append(nn.ModuleList([
#                 nn.Linear(small_dim, large_dim),
#                 nn.Linear(large_dim, small_dim),
#                 CrossAttention(large_dim, heads = cross_attn_heads, dim_head = large_dim_head, dropout = dropout),
#                 nn.Linear(large_dim, small_dim),
#                 nn.Linear(small_dim, large_dim),
#                 CrossAttention(small_dim, heads = cross_attn_heads, dim_head = small_dim_head, dropout = dropout),
#             ]))

#     def forward(self, xs, xl):
#         for f_sl, g_ls, cross_attn_s, f_ls, g_sl, cross_attn_l in self.cross_attn_layers:
        
#             cal_q = f_ls(large_class.unsqueeze(1))
#             cal_qkv = torch.cat((cal_q, x_small), dim=1)
#             cal_out = cal_q + cross_attn_l(cal_qkv)
#             cal_out = g_sl(cal_out)
#             xl = torch.cat((cal_out, x_large), dim=1)

#             # Cross Attn for Smaller Patch
#             cal_q = f_sl(small_class.unsqueeze(1))
#             cal_qkv = torch.cat((cal_q, x_large), dim=1)
#             cal_out = cal_q + cross_attn_s(cal_qkv)
#             cal_out = g_ls(cal_out)
#             xs = torch.cat((cal_out, x_small), dim=1)

#         return xs, xl