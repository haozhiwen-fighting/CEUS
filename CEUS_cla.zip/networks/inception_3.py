import torch.nn as nn
import torch
class ModuleParallel(nn.Module):
    def __init__(self, module):
        super(ModuleParallel, self).__init__()
        self.module = module

    def forward(self, x_parallel):
        return [self.module(x) for x in x_parallel]
class InceptionBlock(nn.Module):
    def __init__(self,in_channels=3,ch1x1=3,ch3x3red=3,ch3x3=1,ch5x5red=3,ch5x5=1,chproj=3):
        super(InceptionBlock,self).__init__()
 
        # 1*1卷积分路
        self.branch1=ModuleParallel(nn.Sequential(
            nn.Conv3d(in_channels=in_channels,out_channels=ch1x1,kernel_size=1,stride=1),
            nn.ReLU(inplace=True)
        ))
        # 3*3卷积分路
        self.branch2=ModuleParallel(nn.Sequential(
            nn.Conv3d(in_channels=in_channels, out_channels=ch3x3red, kernel_size=1, stride=1),
            nn.ReLU(inplace=True),
            nn.Conv3d(in_channels=ch3x3red, out_channels=ch3x3, kernel_size=3, stride=1,padding=1),
            nn.ReLU(inplace=True)
        ))
        # 5*5卷积分路
        self.branch3=ModuleParallel(nn.Sequential(
            nn.Conv3d(in_channels=in_channels, out_channels=ch5x5red, kernel_size=1, stride=1),
            nn.ReLU(inplace=True),
            nn.Conv3d(in_channels=ch5x5red, out_channels=ch5x5, kernel_size=5, stride=1, padding=2),
            nn.ReLU(inplace=True)
        ))
        # 池化层
        self.branch4=ModuleParallel(nn.Sequential(
            nn.MaxPool3d(kernel_size=3,stride=1,padding=1),
            nn.Conv3d(in_channels=in_channels, out_channels=chproj, kernel_size=1, stride=1),
            nn.ReLU(inplace=True)
        ))
 
    def forward(self,x):
        branch1 = self.branch1(x)
        branch2 = self.branch2(x)
        branch3 = self.branch3(x)
        branch4 = self.branch4(x)
        all_0=[branch1[0],branch2[0],branch3[0],branch4[0]]
        all_1=[branch1[1],branch2[1],branch3[1],branch4[1]]
        out0=torch.cat(all_0,dim=1)
        out1=torch.cat(all_1,dim=1)
        out=[out0,out1]
 
        return out

# class InceptionBlock(nn.Module):
#     def __init__(self,in_channels=3,ch1x1=3,ch3x3red=3,ch3x3=1,ch5x5red=3,ch5x5=1,chproj=3):
#         super(InceptionBlock,self).__init__()
 
#         # 1*1卷积分路
#         self.branch1=nn.Sequential(
#             nn.Conv3d(in_channels=in_channels,out_channels=ch1x1,kernel_size=1,stride=1),
#             nn.ReLU(inplace=True)
#         )
#         # 3*3卷积分路
#         self.branch2=nn.Sequential(
#             nn.Conv3d(in_channels=in_channels, out_channels=ch3x3red, kernel_size=1, stride=1),
#             nn.ReLU(inplace=True),
#             nn.Conv3d(in_channels=ch3x3red, out_channels=ch3x3, kernel_size=3, stride=1,padding=1),
#             nn.ReLU(inplace=True)
#         )
#         # 5*5卷积分路
#         self.branch3=nn.Sequential(
#             nn.Conv3d(in_channels=in_channels, out_channels=ch5x5red, kernel_size=1, stride=1),
#             nn.ReLU(inplace=True),
#             nn.Conv3d(in_channels=ch5x5red, out_channels=ch5x5, kernel_size=5, stride=1, padding=2),
#             nn.ReLU(inplace=True)
#         )
#         # 池化层
#         self.branch4=nn.Sequential(
#             nn.MaxPool3d(kernel_size=3,stride=1,padding=1),
#             nn.Conv3d(in_channels=in_channels, out_channels=chproj, kernel_size=1, stride=1),
#             nn.ReLU(inplace=True)
#         )
 
#     def forward(self,x):
#         branch1 = self.branch1(x)
#         branch2 = self.branch2(x)
#         branch3 = self.branch3(x)
#         branch4 = self.branch4(x)
#         all=[branch1,branch2,branch3,branch4]
#         out=torch.cat(all,dim=1)
 
#         return out
