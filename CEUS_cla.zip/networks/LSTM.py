from torchvision import models
from torch import nn
import torch 
class Identity(nn.Module):
	def __init__(self):
		super(Identity,self).__init__()
	def forward(self,x):
		return x
class Resnet18Rnn(nn.Module):
	def __init__(self,num_classes=2,dr_rate=0.1,pretrained=True,rnn_num_layers=1,rnn_hidden_size=768):
		super(Resnet18Rnn,self).__init__()
		baseModel=models.resnet18(pretrained=pretrained)
		num_features=baseModel.fc.in_features
		baseModel.fc=Identity()
		self.baseModel=baseModel
		self.dropout=nn.Dropout(dr_rate)
		self.rnn=nn.LSTM(num_features,rnn_hidden_size,rnn_num_layers)
		# self.fc1=nn.Linear(rnn_hidden_size, num_classes)
	def forward(self,x):
		x=x.permute(0,2,1,3,4)
		b_z,ts,c,h,w=x.shape
		ii=0
		y=self.baseModel((x[:,ii]))
		output,(hn,cn)=self.rnn(y.unsqueeze(1))
		for ii in range(1,ts):
			y=self.baseModel((x[:,ii]))
			out,(hn,cn)=self.rnn(y.unsqueeze(1),(hn,cn))
		# out=self.dropout(out[:-1])
		out=self.dropout(out)
		out=out.view(1,-1)
		# out=self.fc1(out)
		return out

