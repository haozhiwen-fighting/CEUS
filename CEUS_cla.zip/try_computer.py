import numpy as np
import math
import pylab as plt
import matplotlib as mpl
import cv2
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as mcolors
import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt

 
cmap=cv2.imread('C:/Users/hp/Desktop/CEUS_D/01.jpg')
heat_img = cv2.applyColorMap(cmap, cv2.COLORMAP_JET)  # 注意此处的三通道热力图是cv2专有的GBR排列
cv2.imshow('1',heat_img)
df = DataFrame(np.random.randn(10,10))
# df = DataFrame(cmap)
fig = plt.figure(figsize=(12,5))
ax = fig.add_subplot(111)
axim = ax.imshow(df.values,interpolation='nearest')#cmap=plt.cm.gray_r, #cmap用来显示颜色，可以另行设置
plt.colorbar(axim)
plt.show()



def show_cmap(cmap, norm=None, extend=None):
    '''展示一个colormap.'''
    if norm is None:
        norm = mcolors.Normalize(vmin=0, vmax=100)
    im = cm.ScalarMappable(norm=norm, cmap=cmap)

    fig, ax = plt.subplots(figsize=(6, 1))
    fig.subplots_adjust(bottom=0.5)
    fig.colorbar(im, cax=ax, orientation='horizontal', extend=extend)
    plt.show()
cmap=cv2.imread('C:/Users/hp/Desktop/CEUS_D/01.jpg')
show_cmap(cmap)
fig = plt.figure(figsize=(3, 8))
cmap = mpl.cm.Spectral_r
ax3 = fig.add_axes([0.3, 0.2, 0.2, 0.5]) # 四个参数分别是左、下、宽、长
norm = mpl.colors.Normalize(vmin=1.3, vmax=2.5)
bounds = [ round(elem, 2) for elem in np.linspace(1.3, 2.5, 14)] # 
cb3 = mpl.colorbar.ColorbarBase(ax3, cmap=cmap,
                                norm=norm,
                                # to use 'extend', you must
                                # specify two extra boundaries:
                                boundaries= [1.2] + bounds + [2.6],
                                extend='both',
                                ticks=bounds,  # optional
                                spacing='proportional',
                                orientation='vertical')
plt.show()

a=[77.87,84.80,84.80]

print("均值{} 方差{}".format(np.mean(a),math.sqrt(np.std(a))))

b=666666